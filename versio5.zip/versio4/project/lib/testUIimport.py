from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QMainWindow
import sys
import os

class Ui(QMainWindow):
    def __init__(self):
        super(Ui, self).__init__() # Call the inherited classes __init__ method
        dialog = QtWidgets.QFileDialog(self)
        dialog.setWindowTitle('Open PNG File')
        dialog.setNameFilter('PNG files (*.png)')
        dialog.setDirectory(QtCore.QDir.currentPath())
        dialog.setFileMode(QtWidgets.QFileDialog.ExistingFile)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            file_full_path = str(dialog.selectedFiles()[0])

        else:
            return None

        print(file_full_path)
        
app = QtWidgets.QApplication(sys.argv) # Create an instance of QtWidgets.QApplication
window = Ui() # Create an instance of our class
app.exec_() # Start the application
