English:

Español:

Valencià: