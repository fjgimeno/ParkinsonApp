from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMainWindow, QWidget
from PyQt5.QtGui import QIcon, QPixmap
import sqlite3

class Ui_Form(QMainWindow):
    def setupBd(self):
        self.createTable("users.db")
        
    def setupUi(self, Form):
        #self.centralGridLay = QtWidgets.QGridLayout()
        #self.centralGridLay.setContentsMargins(0, 0, 0, 0)
        #self.centralGridLay.setObjectName("centralGridLayout")
        Form.setObjectName("Form")
        Form.resize(854, 480)
        Form.setStyleSheet("QWidget{\n"
"    background-color:rgb(10,10,10);\n"
"}")
        self.labelLogIn = QtWidgets.QLabel(Form)
        self.labelLogIn.setGeometry(QtCore.QRect(160, 240, 163, 75))
        self.labelLogIn.setStyleSheet("QLabel{\n"
"    font-size:25px;\n"
"    color:rgb(255,255,255);\n"
"}")
        self.labelLogIn.setAlignment(QtCore.Qt.AlignCenter)
        self.labelLogIn.setObjectName("labelLogIn")
        self.labelName = QtWidgets.QLabel(Form)
        self.labelName.setGeometry(QtCore.QRect(130, 320, 216, 48))
        self.labelName.setStyleSheet("QLabel{\n"
"    font-size:25px;\n"
"    color:rgb(255,255,255);\n"
"}")
        self.labelName.setAlignment(QtCore.Qt.AlignCenter)
        self.labelName.setObjectName("labelName")
        self.lineEditName = QtWidgets.QLineEdit(Form)
        self.lineEditName.setGeometry(QtCore.QRect(20, 367, 433, 40))
        self.lineEditName.setStyleSheet("QLineEdit{\n"
"    background-color: rgb(120,120,120);\n"
"    color:rgb(255,255,255);\n"
"}")
        self.lineEditName.setObjectName("lineEditName")
        self.labelPassword = QtWidgets.QLabel(Form)
        self.labelPassword.setGeometry(QtCore.QRect(180, 410, 127, 45))
        self.labelPassword.setStyleSheet("QLabel{\n"
"    font-size:25px;\n"
"    color:rgb(255,255,255);\n"
"}")
        self.labelPassword.setAlignment(QtCore.Qt.AlignCenter)
        self.labelPassword.setObjectName("labelPassword")
        self.lineEditPassword = QtWidgets.QLineEdit(Form)
        self.lineEditPassword.setGeometry(QtCore.QRect(20, 460, 433, 40))
        self.lineEditPassword.setStyleSheet("QLineEdit{\n"
"    background-color: rgb(120,120,120);\n"
"    color:rgb(255,255,255);\n"
"}")
        self.lineEditPassword.setObjectName("lineEditPassword")
        self.pushButtonLogIn = QtWidgets.QPushButton(Form)
        self.pushButtonLogIn.setGeometry(QtCore.QRect(21, 520, 200, 50))
        self.pushButtonLogIn.setStyleSheet("QPushButton{\n"
"    background-color: rgb(120,120,120);\n"
"    color:rgb(255,255,255);\n"
"    font-size:20px;\n"
"}")
        self.pushButtonLogIn.setObjectName("pushButtonLogIn")
        self.pushButtonGuest = QtWidgets.QPushButton(Form)
        self.pushButtonGuest.setGeometry(QtCore.QRect(253, 520, 200, 50))
        self.pushButtonLogIn.clicked.connect(self.buttonClikLogIn)
        self.pushButtonGuest.setStyleSheet("QPushButton{\n"
"    background-color: rgb(120,120,120);\n"
"    color:rgb(255,255,255);\n"
"    font-size:20px;\n"
"}")
        self.pushButtonGuest.setObjectName("pushButtonGuest")
        self.pushButtonGuest.clicked.connect(self.buttonClikGuest)
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)
        
        #self.centralGridLay.addWidget(self.labelLogIn)
        #self.setLayout(self.centralGridLay)
        

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.labelLogIn.setText(_translate("Form", "Log In"))
        self.labelName.setText(_translate("Form", "Name"))
        self.labelPassword.setText(_translate("Form", "Password"))
        self.pushButtonLogIn.setText(_translate("Form", "Log In"))
        self.pushButtonGuest.setText(_translate("Form", "Guest"))

    def buttonClikLogIn(self):
        self.verifyUser(self.lineEditName.text(), hash(self.lineEditPassword.text()))

    def buttonClikGuest(self):
        #NOT implemented
        pass

    def verifyUser(self, username, password):
        conn = sqlite3.connect('users.db') 
        c = conn.cursor()
        c.execute("select username from users where username=?", (username,))
        data = c.fetchall()
        if not data:
            print ('Incorrect user or password')
        else:
            #NOT implemented
            print ('found')
        conn.commit()
        conn.close()

    def createUser(self, username, password):
        conn = sqlite3.connect('users.db') 
        c = conn.cursor()
        c.execute("select username from users where username=?", (username,))
        data = c.fetchall()
        if not data:
            #print ('not found')
            c.execute("INSERT INTO users(username, pwd) VALUES (?,?)", (username, password))
        #else:
            #print ('found')
        conn.commit()
        conn.close()

    def createTable(self, tablename):
        conn = sqlite3.connect(tablename)
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username STRING, pwd BIGINT)")                                       
        conn.close()
        
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupBd()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())