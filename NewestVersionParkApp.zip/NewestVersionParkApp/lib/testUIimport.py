from PyQt5 import QtWidgets, uic, Qt
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtGui import QPixmap
import sys
import os

class Ui(QMainWindow):
    def __init__(self):
        super(Ui, self).__init__() # Call the inherited classes __init__ method
        os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + "/res/ui")
        uic.loadUi('PatientUserInfoUIdef.ui', self) # Load the .ui file
        os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + "/res/app_img")
        pixmap = QPixmap('shrek.jpg')
        smaller_pixmap = pixmap.scaled(241, 221)
        pixmap2 = QPixmap('shrek2.png')
        smaller_pixmap2 = pixmap2.scaled(271, 401)
        self.labelFacePic.setPixmap(smaller_pixmap)
        self.labelBodyPic.setPixmap(smaller_pixmap2)
        self.show() # Show the GUI
        print(os.path.sep)
        print(os.path.dirname(__file__) + os.path.sep + "Manolo.exe")
        
app = QtWidgets.QApplication(sys.argv) # Create an instance of QtWidgets.QApplication
window = Ui() # Create an instance of our class
app.exec_() # Start the application