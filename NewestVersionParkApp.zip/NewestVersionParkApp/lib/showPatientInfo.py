from PyQt5 import QtWidgets, QtCore, uic
from PyQt5.QtWidgets import QMainWindow, QDialog
from PyQt5.QtGui import QPixmap
import sys
import os
from lib.databasemanager import dbMan
class PatientInfo(QtWidgets.QDialog):
    dbManager = dbMan()
    def __init__(self):
        super(PatientInfo, self).__init__() # Call the inherited classes __init__ method
        os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + "/res")
        uic.loadUi('ui/PatientUserInfoUIdef.ui', self) # Load the .ui file
        self.loadPatientImages()
        
    def writePatientInfo(self, dni):
        info = self.dbManager.getPatientInfo(dni)
        self.labelName.setText(str(info[3]))#3
        self.labelSurname.setText(str(info[2]))#2
        self.labelDNI.setText(str(info[0]))#0
        self.labelSIP.setText(str(info[1]))#1
        self.labelEmail.setText(str(info[5]))#5
        self.labelPhone.setText(str(info[4]))#4
        self.labelBirthday.setText(str(info[8]))#8
        self.labelSex.setText(str(info[9]))#9
        self.labelHeight.setText(str(info[6]))#6
        self.labelWeight.setText(str(info[7]))#7
        self.labelDiagnosticDate.setText(str(info[10]))#10
        self.labelParkPhase.setText(str(info[11]))#11
        self.labelImc.setText(str(info[12]))#12
        self.labelMedication.setText(str(info[13]))#13

    def loadPatientImages(self):
        pixmap = QPixmap('patImg/face/facePlaceholder.png')
        smaller_pixmap = pixmap.scaled(241, 221)
        pixmap2 = QPixmap('patImg/body/bodyPlaceholder.png')
        smaller_pixmap2 = pixmap2.scaled(271, 401)
        self.labelFacePic.setPixmap(smaller_pixmap)#14
        self.labelBodyPic.setPixmap(smaller_pixmap2)#15